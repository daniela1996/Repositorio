import java.util.ArrayList;
import java.net.*;
import java.io.*;

public class SocketServer {
	
    public static void main(String[] args) throws IOException {    
        
	ArrayList<SocketServerHilo> lista   =   new ArrayList<>();
        int num_cliente                     =   0;
	
        try {
            ServerSocket servidor               =   new ServerSocket(3000);			
            do{
                System.out.println("Esperando cliente...");							
                Socket socketConectado          =   servidor.accept();
                num_cliente++;
                            
                SocketServerHilo hilo_c         =   new SocketServerHilo(socketConectado,num_cliente,lista);
                lista.add(hilo_c);
                Runnable nuevoSocket            =   hilo_c;
              
                Thread hiloSocket               =   new Thread(nuevoSocket);
                hiloSocket.start();
												
		}while(true);
		}catch (IOException excepcion) {			
                    System.out.println(excepcion);
		}

    }
}