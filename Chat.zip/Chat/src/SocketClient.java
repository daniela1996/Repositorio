import javax.swing.JTextArea;
import java.io.*;  
import java.net.*;


public class SocketClient implements Runnable{
    
    String              texto;
        
    OutputStream        output_salida;
    DataOutputStream    data_salida;
    boolean             salida          =true;

    InputStream         entrada;
    DataInputStream     data_entrada;

    Socket              cliente_socket;
    Thread              hilo_mensaje;
    JTextArea           mostrar_tA;
        
    public SocketClient(JTextArea mostrar_tA){
            
        this.mostrar_tA        =   mostrar_tA;
	hilo_mensaje           =   new Thread(this);
	hilo_mensaje.start();
	
        try {	
            cliente_socket = new Socket("127.0.0.1", 3000);  
            output_salida  = cliente_socket.getOutputStream();
            data_salida    = new DataOutputStream(output_salida);

            entrada        = cliente_socket.getInputStream();
            data_entrada   = new DataInputStream(entrada);
 
            texto          = data_entrada.readUTF();
                        
            mostrar_tA.setText(mostrar_tA.getText()+texto);
	}catch (Exception e) {
            System.err.println("Error: " + e);
		}
	}

    public void mensaje(String mensaje){
	try{	
            data_salida.writeUTF(mensaje+"\n");
            }catch (IOException e) {
		e.printStackTrace();
		}
	}
		
    public void run() {
	Thread ct= Thread.currentThread();
	if(ct==hilo_mensaje){
            try{
		do{	
                    texto = data_entrada.readUTF();
                    mostrar_tA.setText(mostrar_tA.getText()+texto);
		}while(true);
		
       }catch(Exception e){
           System.out.println("Error: "+e);
	}
            }
        try{
            data_salida.close();
            data_entrada.close();
            cliente_socket.close();
	}catch(IOException e) {
            e.printStackTrace();
	}
    }
}