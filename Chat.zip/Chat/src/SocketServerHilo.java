import java.net.*;
import java.util.ArrayList;
import java.io.*;

public class SocketServerHilo implements Runnable {

    String                      mensaje;
    OutputStream                salida;
    DataOutputStream            data_salida;

    InputStream                 entrada;
    DataInputStream             data_entrada;

    Socket                      socket;
    ArrayList<SocketServerHilo> lista;
    int                         num_cliente;

    public SocketServerHilo(Socket socket,int num_cliente,ArrayList<SocketServerHilo> lista){
	try{
            this.num_cliente    =   num_cliente;
            this.lista          =   lista;
            this.socket         =   socket;			
            }catch (Exception e) {
                System.out.println("Error: "+e);
		}		
	}

    public void run() {	
        try{			
            salida      = socket.getOutputStream();
            data_salida = new DataOutputStream(salida);

            entrada      = socket.getInputStream();
            data_entrada = new DataInputStream(entrada);

            do{
		mensaje = data_entrada.readUTF();	
				
		for(int i=0;i<lista.size();i++){
                    lista.get(i).data_salida.writeUTF("Cliente "+num_cliente+": "+mensaje);
                        }
                }while(!mensaje.equals("bye"));
            }catch (Exception e){
                    System.out.println("Error"+e);
		}		
		
	try{
            data_salida.close();
            data_entrada.close();
            socket.close();			
            }catch(IOException excepcion){
		System.out.println(excepcion);
		}			
	}
}