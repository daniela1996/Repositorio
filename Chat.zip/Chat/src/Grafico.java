import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.net.URL;
import javax.swing.*;

public class Grafico implements Runnable{
    
    JFrame              frame; 
    JTextArea           texto_tA;  
    JTextField          texto_txt; 
    JButton             texto_btn; 
	
    JScrollPane         barra; 
    JLabel              chica_lbl;
    JLabel              chico_lbl;
    
    String              recibido;
    OutputStream        salida;
    DataOutputStream    data_salida;

    InputStream         entrada;
    DataInputStream     data_entrada;

    Socket              cliente;
    Thread              hilo_captura;
	
	
    public Grafico() {
        frame        =   new JFrame("Chat");
        texto_tA     =   new JTextArea();
        texto_txt    =   new JTextField();
        chica_lbl    =   new JLabel();
        chico_lbl    =   new JLabel();
        texto_btn    =   new JButton("Enviar");
	barra        =   new JScrollPane(texto_tA);
        
        chica_lbl.setIcon(new ImageIcon("chica.jpg"));
        chico_lbl.setIcon(new ImageIcon("chico.jpg"));

        texto_tA. setFont(new Font("Comic Sans Ms",Font.BOLD,15));

        frame.setLayout(null);
        
        barra.setBounds(new Rectangle(250,20,400,350));
        texto_txt.setBounds(250,400,250,40);
        texto_btn.setBounds(520,405,120,30);
        chica_lbl.setBounds(30,20,200,200);
        chico_lbl.setBounds(30,260,200,200);
        
        frame.add(texto_btn);
        frame.add(texto_txt);
        frame.add(barra);
        frame.add(chica_lbl);
        frame.add(chico_lbl);
        
	frame.setSize(700,530);
	frame.setLocationRelativeTo(null);
	frame.setVisible(true);
	evento();
	
        try {	
            cliente         =   new Socket("127.0.0.1", 3000);  
            salida          =   cliente.getOutputStream();
            data_salida     =   new DataOutputStream(salida);

            entrada         =   cliente.getInputStream();
            data_entrada    =   new DataInputStream(entrada);
 
            recibido        =   data_entrada.readUTF();
	    texto_tA.setText(texto_tA.getText()+recibido);
            
            }catch (Exception e) {
		System.err.println("Error: "+e);
		}
		
            hilo_captura    =   new Thread(this);
            hilo_captura.start();
	}

    public void evento() {
        
	texto_btn.addActionListener(
                new ActionListener(){
                    public void actionPerformed(ActionEvent evento){
			try {
                            if(!(texto_txt.getText()).equals("")){
                            data_salida.writeUTF(texto_txt.getText()+"\n");
                            }else{
                                JOptionPane.showMessageDialog(null,"Escriba un mensaje","Campo vacio",JOptionPane.ERROR_MESSAGE);
                            }
                            }catch(IOException e){
				e.printStackTrace();
				}
							
			}	
		});
		
    }
public void run() {
	Thread current= Thread.currentThread();
	if(current==hilo_captura){
            try {
		do{
                    recibido = data_entrada.readUTF();
                    texto_tA.setText(texto_tA.getText()+recibido);
                }while(true);
            } catch(Exception e) {
                   texto_tA.setText(texto_tA.getText()+"Error al enviar mensaje \n ");
		}
	}
        try {
	data_salida.close();
	data_entrada.close();
        cliente.close();
	} catch (IOException e) {
            e.printStackTrace();
	}
}		

public static void main(String[] args) {
    Grafico g   =    new Grafico();
    }
	
}
