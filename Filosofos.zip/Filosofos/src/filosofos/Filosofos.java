package filosofos;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Filosofos extends JFrame implements Runnable{
    String img1                     =   "pensando.jpg";
    String img2                     =   "comer.jpg";
    String img3                     =   "esperar.jpg";
    JLabel[] images                 =   new JLabel[5];
    ImageIcon[] icons               =   new ImageIcon[5];
    Thread[] hilos            =   new Thread[5];
    
    public void run() {
	Thread hiloin      =   Thread.currentThread();
	while(hilos[0]==hiloin){
            Random rnd              =   new Random();
            int espera              =  (int)(rnd.nextDouble()*10.0)+5;
            try{
		if(!icons[0].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                    if(icons[4].getDescription().equalsIgnoreCase(img2)||icons[1].getDescription().equalsIgnoreCase(img2)){
			icons[0]     =   new ImageIcon(img3);
			images[0].setIcon(icons[0]);
			}else{
                            icons[0] =new ImageIcon(img2);
                            images[0].setIcon(icons[0]);
			}
		
		if(!icons[0].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
		    if(!icons[0].getDescription().equalsIgnoreCase(img3)){
                        icons[0]     =   new ImageIcon(img1);
                        images[0].setIcon(icons[0]);
                    }
		if(!icons[0].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                    } catch (Exception e){
			}
		}
		
    while(hilos[1]==hiloin){
	Random rnd  =   new Random();
	int espera  =   (int)(rnd.nextDouble() * 10.0)+5;
	try{
            if(!icons[1].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
		if(icons[0].getDescription().equalsIgnoreCase(img2)||icons[2].getDescription().equalsIgnoreCase(img2)){
                    icons[1]     =   new ImageIcon(img3);
                    images[1].setIcon(icons[1]);
		}else{
                    icons[1]     =   new ImageIcon(img2);
                    images[1].setIcon(icons[1]);
                    }
            if(!icons[1].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                if(!icons[1].getDescription().equalsIgnoreCase(img3)){
                    icons[1]     =   new ImageIcon(img1);
                    images[1].setIcon(icons[1]);
                }
                if(!icons[1].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                    }catch (Exception e){
			    }
		}

	while(hilos[2]==hiloin){
            Random rnd      =   new Random();
            int espera      =  (int)(rnd.nextDouble() * 10.0)+5;
            try{
		if(!icons[2].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                    if(icons[1].getDescription().equalsIgnoreCase(img2)||icons[3].getDescription().equalsIgnoreCase(img2)){
			icons[2]     =   new ImageIcon(img3);
			images[2].setIcon(icons[2]);
		}else{
                    icons[2]         =   new ImageIcon(img2);
                    images[2].setIcon(icons[2]);
                    }
		if(!icons[2].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
		    if(!icons[2].getDescription().equalsIgnoreCase(img3)){
                        icons[2]     =   new ImageIcon(img1);
                        images[2].setIcon(icons[2]);
                        }
			if(!icons[2].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
			} catch (Exception e) {
			    }
		}

	while(hilos[3]==hiloin){
            Random rnd  = new Random();
            int espera  = (int)(rnd.nextDouble() * 10.0)+5;
            try{
		if(!icons[3].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                    if(icons[2].getDescription().equalsIgnoreCase(img2)||icons[4].getDescription().equalsIgnoreCase(img2)){
			icons[3]     =   new ImageIcon(img3);
			images[3].setIcon(icons[3]);
			}else{
                        icons[3]     =   new ImageIcon(img2);images[3].setIcon(icons[3]);
			}
		if(!icons[3].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
		    if(!icons[3].getDescription().equalsIgnoreCase(img3)){
                        icons[3]     =   new ImageIcon(img1);
                        images[3].setIcon(icons[3]);
                        }
			if(!icons[3].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
			}catch (Exception e){
			        }
		}
		
	while(hilos[4]==hiloin){
            Random rnd  = new Random();
            int espera  = (int)(rnd.nextDouble() * 10.0)+5;
            try {
		if(!icons[4].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                    if(icons[3].getDescription().equalsIgnoreCase(img2)||icons[0].getDescription().equalsIgnoreCase(img2)){
			icons[4]     =   new ImageIcon(img3);
			images[4].setIcon(icons[4]);
			}else{
                            icons[4] =   new ImageIcon(img2);images[4].setIcon(icons[4]);
			}
                    if(!icons[4].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
                        if(!icons[4].getDescription().equalsIgnoreCase(img3)){
                            icons[4]=new ImageIcon(img1);
                            images[4].setIcon(icons[4]);
                        }
                        if(!icons[4].getDescription().equalsIgnoreCase(img3))Thread.sleep (espera*1000);
			}catch(Exception e){
			        }
		}
	}
	
	public static void main(String[] args) {
		Filosofos frame   =   new Filosofos();
		frame.setSize(1300,700);
		frame.setLocationRelativeTo(null);
		frame.setLayout(null);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
		for (int i=0;i<frame.images.length;i++){
			frame.icons[i]   =   new ImageIcon(frame.img1);
			frame.images[i]  =   new JLabel(frame.icons[i]);
                        if(i==0){
                            frame.images[i].setBounds(80,200,300,210);
                        }
                        if(i==1){
                            frame.images[i].setBounds(520,40,300,210);
                        }
                        if(i==2){
                                frame.images[i].setBounds(960,200,300,210);
                            }
                        if(i==3){
                                frame.images[i].setBounds(360,420,300,210);
                            }
                        if(i==4){
                            frame.images[i].setBounds(700,420,300,210);
                        }
			frame.hilos[i]        =   new Thread(frame);
			frame.hilos[i].start();			
		}	
		for (int i=0;i<frame.images.length;i++){ 
                    frame.add(frame.images[i]);
                }
		frame.setVisible(true);	
		
	}
}

